# SERV Results — Landing Page

A simple, design-forward landing page for **SERV Results** (servresults.com), the
first-party data and lead-conversion platform for automotive dealers.

## What's here

| File | Purpose |
|------|---------|
| `index.html` | The full landing page (single page, semantic HTML) |
| `styles.css` | Design system + all styling (no framework, no build step) |
| `script.js` | Sticky-nav state, scroll reveals, smooth in-page scrolling |

Open `index.html` in any browser — there is no build step or dependency to install.

## Design direction

Built to read as **professional, confident, and results-driven** for a dealer-group audience:

- **Palette:** deep automotive navy with an electric blue → teal gradient and a gold
  confidence accent.
- **Type:** `Sora` (display) + `Inter` (body) via Google Fonts.
- **Motion:** subtle scroll-reveal, floating stat chips, and hover lift — energetic
  without being noisy.
- **Structure:** hero → trust strip → key stats → the challenge → the Auto Insights
  solution → how it works → social proof → demo CTA → footer.

## Copy

All content was rewritten fresh around SERV Results' core positioning: helping dealers
**de-anonymize ~40% of website traffic** and **lift website leads 30%+** using
transparent, dealer-owned first-party data instead of third-party lead resellers.

> Phone/email in the footer and CTA are placeholders (`hello@servresults.com`,
> `+1 (800) 555-0199`) — swap in the real contact details before going live.

## AI-generated imagery

Per the brief, the photography is **AI-generated** rather than stock. Images are
produced on the fly by the [Pollinations](https://pollinations.ai) FLUX endpoint and
embedded directly via URL — no API key, no asset pipeline. Each `image.pollinations.ai`
URL carries the generation prompt plus a fixed `seed`, so the same image renders every
time. The hero and CTA images sit behind CSS gradient veils, so the layout stays sharp
even while images load.

To swap an image, edit the prompt text in the corresponding URL (or replace the URL with
a locally saved render in an `assets/` folder for guaranteed offline performance).

## Next steps

- Replace placeholder contact info and wire the CTA to a real demo-booking form.
- Optionally download the AI renders locally for faster, dependency-free loading.
- Add analytics + an Open Graph share image.
